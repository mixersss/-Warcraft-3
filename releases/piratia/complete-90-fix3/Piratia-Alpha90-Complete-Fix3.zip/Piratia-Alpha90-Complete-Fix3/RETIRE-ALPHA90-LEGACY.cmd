@echo off
call "%~dp0server-shops\Retire-World-Legacy-IDs.cmd"
