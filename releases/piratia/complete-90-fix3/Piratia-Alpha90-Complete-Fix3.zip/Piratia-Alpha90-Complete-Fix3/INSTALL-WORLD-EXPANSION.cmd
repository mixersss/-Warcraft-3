@echo off
call "%~dp0server-shops\Install-World-Expansion.cmd"
