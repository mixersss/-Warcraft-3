@echo off
call "%~dp0server-shops\Restore-Original-Gems.cmd"
