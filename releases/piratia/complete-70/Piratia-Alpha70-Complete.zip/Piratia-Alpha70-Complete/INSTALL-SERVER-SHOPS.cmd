@echo off
call "%~dp0server-shops\Install-City-Shops.cmd"
