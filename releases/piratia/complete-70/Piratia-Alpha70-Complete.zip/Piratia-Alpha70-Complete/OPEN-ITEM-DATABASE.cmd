@echo off
start "" "%~dp0server-shops\native\item-database.html"
