@echo off
call "%~dp0server-shops\Update-Client-Prices.cmd"
