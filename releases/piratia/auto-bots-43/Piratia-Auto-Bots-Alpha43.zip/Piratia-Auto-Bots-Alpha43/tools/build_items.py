"""Extract numeric item types/equipment constraints; no descriptions/models copied."""
import argparse
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]


def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('item_info',type=Path);args=p.parse_args()
 types,gear={},{}
 for line in args.item_info.read_bytes().decode('gb18030',errors='replace').splitlines():
  a=line.split('\t')
  if not a[0].isdigit() or len(a)<65:continue
  identity,kind=int(a[0]),int(a[10]);types[identity]=kind
  weapon=1<=kind<=10
  if not weapon and kind not in (11,20,22,23,24,25,26,27,29):continue
  links=[int(v) for v in a[28].split(',')]
  if weapon:links=[v for v in links if v in (9,6)]
  if not links or any(v not in (0,2,3,4,5,6,7,8,9) for v in links):continue
  displaces=[int(v) for v in a[29].split(',') if v.isdigit() and int(v) in (0,2,3,4,5,6,7,8,9)]
  def value(text):
   try:return max(0,float(text.split(',')[0]))
   except ValueError:return 0
  score=value(a[60])+value(a[61])+value(a[62])*4+value(a[63])*.05+value(a[64])*.05
  if kind==29:score=10+int(a[24]) # Native coral utility, not physical damage.
  gear[identity]={'level':int(a[24]),'jobs':[int(v) for v in a[25].split(',')],
                  'links':links,'bodies':[1,2,3,4] if a[23]=='-1' else sorted({int(v) for v in a[23].split(',') if v in ('1','2','3','4')}),
                  'displaces':displaces or [links[0]],'requires_links':displaces,
                  'kind':kind,'strength':value(a[52]),'agility':value(a[53]),'spirit':value(a[56]),'constitution':value(a[55]),'accuracy':value(a[54]),'attack_speed':value(a[58]),
                  'score':score}
 (ROOT/'assets/items.json').write_text(json.dumps({'types':types,'gear':gear},separators=(',',':'))+'\n')
 print('Extracted numeric item types:',len(types),'gear:',len(gear))


if __name__=='__main__':main()
