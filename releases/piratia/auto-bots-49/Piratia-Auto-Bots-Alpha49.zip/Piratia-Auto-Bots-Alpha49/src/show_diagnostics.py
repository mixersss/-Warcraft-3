"""Display selected bot quest/travel diagnostics; never inspect the private data folder."""
import argparse
import hashlib
import json
import os
import re
import sys
from pathlib import Path
from professions import describe


def render_report(report):
    quest=report.get('adventure',{})
    travel=report.get('travel',{})
    role=report.get('class_path',{})
    vendor=report.get('vendor',{})
    lines=[f"Бот {report.get('bot_index','?')}: цель развития {role.get('label','?')}",
           f"  Уровень={quest.get('level','?')}; золото={quest.get('gold','?')}; состояние={report.get('hunt',{}).get('state','?')}",
           f"  Сумка: {quest.get('bag_used','?')}/{quest.get('bag_capacity','?')}; свободно={quest.get('free_bag_slots','?')}",
           f"  Миссии: {json.dumps(quest.get('active_missions',{}),ensure_ascii=False)}; принятия={quest.get('accepted_confirmed',0)}; сдачи={quest.get('deliveries_confirmed',0)}",
           f"  Квест: {quest.get('state','нет данных')}; NPC={quest.get('destination_npc','?')}; этап={quest.get('dialogue_stage')}",
           f"  Причина: {quest.get('last_problem') or 'не указана'}; журнал={quest.get('journal_received')}; расстояние={quest.get('npc_distance')}",
           f"  Предложения NPC: {json.dumps(quest.get('last_offers',[]),ensure_ascii=False)}",
           f"  Переход: {travel.get('state','нет данных')}; город={travel.get('destination')}; этап={travel.get('dialogue_stage')}; прибытия={travel.get('confirmed_arrivals',0)}",
           f"  Меню телепортера: {json.dumps(travel.get('last_menu',[]),ensure_ascii=False)}"]
    fight=report.get('hunt',{})
    actual=quest.get('profession',fight.get('world',{}).get('profession'))
    lines.append(f"  Фактическая профессия: {describe(actual)}; проверка задания={json.dumps(quest.get('objective_review',{}),ensure_ascii=False)}")
    lines.append(f"  Поиск в фоне: {fight.get('background_planning_task')}; ожидание действия={json.dumps(fight.get('action_wait',{}),ensure_ascii=False)}")
    lines.append(f"  Проверка зоны боя: {json.dumps(fight.get('combat_safety',{}),ensure_ascii=False)}")
    lines.append(f"  Выход на сушу: {json.dumps(fight.get('offmesh_recovery',{}),ensure_ascii=False)}")
    lines.append(f"  Знания мобов: {json.dumps(fight.get('mob_knowledge',{}),ensure_ascii=False)}")
    lines.append(f"  Портал для сокращения пути: {json.dumps(fight.get('portal_shortcut',{}),ensure_ascii=False)}")
    lines.append('  Экипировка: '+json.dumps(report.get('equipment',{}),ensure_ascii=False))
    lines.append('  Боевые навыки: '+json.dumps(fight.get('combat_skills',{}),ensure_ascii=False))
    lines.append('  Знания НПС: '+json.dumps(fight.get('npc_knowledge',{}),ensure_ascii=False))
    lines.append('  Билд и очки: '+json.dumps(report.get('progression',{}),ensure_ascii=False))
    lines.append('  Причина выбора мобов: '+json.dumps(fight.get('farm_reason',{}),ensure_ascii=False))
    lines.append('  Текущая цель и её выгодность: '+json.dumps(fight.get('farm_plan',{}).get('target'),ensure_ascii=False))
    lines.append('  Исключённые невыгодные виды: '+json.dumps(fight.get('hunting_learning',{}).get('inefficient_models',[]),ensure_ascii=False))
    lines.append('  Развитие навыков: '+json.dumps(report.get('skills',{}).get('development_plan',{}),ensure_ascii=False))
    lines.append('  Банк: '+json.dumps(report.get('bank',{}),ensure_ascii=False))
    lines.append('  Личная торговля: '+json.dumps(report.get('direct_trade',{}),ensure_ascii=False))
    mechanics=report.get('mechanics',{})
    lines.append('  Знания механик: '+json.dumps({k:mechanics.get(k) for k in ('lua_files','named_functions','reviewed_mechanics','indexed_only_mechanics','requires_reaudit','known_stones','known_ship_types','map_rules')},ensure_ascii=False))
    lines.append('  Наблюдаемые чертежи и резерв материалов: '+json.dumps({'blueprints':mechanics.get('blueprints',[]),'reserved':mechanics.get('reserved_recipe_materials',{})},ensure_ascii=False))
    xp=fight.get('hunting_learning',{})
    lines.append(f"  Прокачка: опыт/мин={xp.get('session_xp_per_minute','?')}; прирост={xp.get('session_xp_net','?')}; без опыта={xp.get('seconds_without_xp','?')} сек. (текущая сессия)")
    lines.append(f"  Планировщик: {json.dumps(report.get('route_planning',{}),ensure_ascii=False)}")
    lines.append(f"  Путь к продавцу: {vendor.get('merchant')} ({vendor.get('merchant_region')}); NPC={vendor.get('destination')}; точка подхода={vendor.get('route_goal')}; снимок={report.get('time_utc')}")
    obstacles=fight.get('movement_obstacles',{})
    lines.append(f"  Препятствия: неожиданных остановок={obstacles.get('unexpected_stops',0)}; последний шаг={json.dumps(obstacles.get('last_step'),ensure_ascii=False)}")
    world=fight.get('world',{})
    lines.append(f"  Персонаж: метка={report.get('character_tag','не указана')}; HP={world.get('hp')}/{world.get('max_hp')}; карта={world.get('map')}; позиция={world.get('position')}; состояние длится={fight.get('state_seconds')} сек.")
    lines.append(f"  Сумка мешает NPC: {fight.get('inventory_blocker') or 'нет'}; подбор={json.dumps(report.get('loot',{}),ensure_ascii=False)}")
    lines.append(f"  Бой: цель={fight.get('target_id')}; HP={fight.get('target_hp')}; совместная={fight.get('shared_target')}; без урона={fight.get('seconds_since_target_damage')}; смены без урона={fight.get('no_damage_retargets',0)}")
    lines.append(f"  Версия: {report.get('version','не указана')}")
    lines.append(f"  Пати для кача: {json.dumps(report.get('hunt_party',{}),ensure_ascii=False)}")
    lines.append(f"  Мировой чат: {json.dumps(report.get('public_chat',{}),ensure_ascii=False)}")
    lines.extend([f"  Продажа: {vendor.get('state','нет данных')}; запросы={vendor.get('sale_requests',0)}; подтверждено={vendor.get('confirmed_sales',0)}; тайм-ауты={vendor.get('confirmation_timeouts',0)}",f"  Предметы: {json.dumps(vendor.get('bag_items',[]),ensure_ascii=False)}"])
    return '\n'.join(lines)


def character_tag(name):
    name=name.strip()
    if not re.fullmatch(r'bot[0-9a-f]{8}',name,re.IGNORECASE):raise ValueError('Ожидается ник вида Bot38977e75')
    canonical='Bot'+name[3:].lower()
    return hashlib.sha256(canonical.encode('utf-8')).hexdigest()[:12]


def collect(root,name=None):
    lines=['Диагностика квестов и переходов. Папка программы: '+str(root)]
    paths=sorted(root.glob('bot-report-*.json'))
    if not paths:
        lines.append('Отчёты пока не найдены. Запусти ботов из этой же папки и подожди 30 секунд. Не удаляй data.')
    wanted=character_tag(name) if name is not None else None
    found=0
    for path in paths:
        try:
            report=json.loads(path.read_text(encoding='utf-8-sig'))
            if wanted and report.get('character_tag')!=wanted:continue
            found+=1
            if wanted:lines.append('Отчёт нужного бота: '+path.name)
            lines.append(render_report(report))
        except (OSError,ValueError,TypeError,AttributeError):
            if not wanted:lines.append(path.name+': отчёт пока недоступен; повтори позже.')
    if wanted and not found:lines.append('Ник не найден среди отчётов. Метки доступны с Alpha34: запусти обновлённых ботов, подожди 30 секунд и повтори поиск. Не удаляй data.')
    return '\n\n'.join(lines)


def main():
    if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8',errors='replace')
    root=Path(__file__).resolve().parents[1]
    parser=argparse.ArgumentParser(description=__doc__)
    group=parser.add_mutually_exclusive_group()
    group.add_argument('--name')
    group.add_argument('--name-env')
    args=parser.parse_args()
    name=os.environ.get(args.name_env,'') if args.name_env else args.name
    try:text=collect(root,name)
    except ValueError as error:print(str(error));return
    print(text)
    path=root/('selected-bot-diagnostics.log' if name is not None else 'bot-diagnostics.log')
    path.write_text(text,encoding='utf-8')
    print('\nКопия диагностики: '+str(path))


if __name__=='__main__':main()
