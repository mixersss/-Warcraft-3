# Shared by the Windows setup helper and the standalone persistence regression test.
function Initialize-BotSecondaryPasswordState {
    param([Parameter(Mandatory=$true)]$State,
          [ValidateRange(1,400)][int]$Count,
          [Parameter(Mandatory=$true)][scriptblock]$CreateProtectedPassword)
    $changed = $false
    foreach ($entry in @($State.bots | Select-Object -First $Count)) {
        if ($null -eq $entry.PSObject.Properties['secondary_password_dpapi']) {
            $protected = [string](& $CreateProtectedPassword)
            if ([string]::IsNullOrWhiteSpace($protected)) { throw 'Missing protected secondary password.' }
            Add-Member -InputObject $entry -NotePropertyName 'secondary_password_dpapi' -NotePropertyValue $protected
            $changed = $true
        }
    }
    return $changed
}

function Save-BotState {
    param([Parameter(Mandatory=$true)]$State,
          [Parameter(Mandatory=$true)][string]$Path)
    $fullPath = [IO.Path]::GetFullPath($Path)
    $temporary = "$fullPath.tmp"
    $json = ConvertTo-Json -InputObject $State -Depth 8
    [IO.File]::WriteAllText($temporary, $json, (New-Object Text.UTF8Encoding($false)))
    if ([IO.File]::Exists($fullPath)) {
        # PowerShell converts $null to an empty string for this .NET string
        # parameter. File.Replace rejects it instead of meaning "no backup".
        # A concrete unique path preserves the previous state and avoids that
        # conversion as well as collisions with an existing backup.
        $backup = $fullPath + '.backup-' + [Guid]::NewGuid().ToString('N')
        [IO.File]::Replace($temporary, $fullPath, $backup)
    } else {
        [IO.File]::Move($temporary, $fullPath)
    }
}

function Assert-BotAccountMayBeCreated {
    param([ValidateRange(1,400)][int]$Ordinal,
          [ValidateRange(0,400)][int]$ExistingCount,
          [int[]]$ConfirmedIndices = @())
    if ($Ordinal -le $ExistingCount -or $Ordinal -in $ConfirmedIndices) {
        throw 'A protected saved account is missing. Restore the database; no replacement created.'
    }
}

# Both expansion journals remain immutable except native enter-world confirmations.
function Get-BotGrowthConfirmedIndices {
    param([Parameter(Mandatory=$true)][string]$DataPath)
    $all = @()
    foreach ($target in @(300,400)) {
        $name = if ($target -eq 300) { 'population-growth.json' } else { 'population-growth-400.json' }
        $path = Join-Path $DataPath $name
        if (-not [IO.File]::Exists($path)) { continue }
        $growth = [IO.File]::ReadAllText($path) | ConvertFrom-Json
        if ($growth.version -ne 1 -or $growth.base_count -ne ($target-100) -or $growth.target_count -ne $target) {
            throw 'Invalid growth journal; protected accounts cannot be replaced.'
        }
        $indices = @($growth.confirmed_indices)
        if (@($indices | Select-Object -Unique).Count -ne $indices.Count) { throw 'Duplicate growth confirmations.' }
        foreach ($index in $indices) {
            if ($index -isnot [int] -and $index -isnot [long]) { throw 'Invalid growth confirmation.' }
            if ($index -le ($target-100) -or $index -gt $target) { throw 'Growth confirmation outside authorised range.' }
            $all += [int]$index
        }
    }
    return $all
}
