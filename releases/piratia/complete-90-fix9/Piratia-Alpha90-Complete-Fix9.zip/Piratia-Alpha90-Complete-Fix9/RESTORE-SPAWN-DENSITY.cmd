@echo off
call "%~dp0server-shops\Restore-Spawn-Density.cmd"
