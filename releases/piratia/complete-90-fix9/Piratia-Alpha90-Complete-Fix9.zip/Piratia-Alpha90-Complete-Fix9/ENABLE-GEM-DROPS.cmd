@echo off
call "%~dp0server-shops\Enable-Gem-Drops.cmd"
